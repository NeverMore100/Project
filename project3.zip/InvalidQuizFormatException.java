public class InvalidQuizFormatException extends Exception{
    public InvalidQuizFormatException(){

    }
}
